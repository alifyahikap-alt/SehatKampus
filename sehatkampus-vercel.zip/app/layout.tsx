import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "SehatKampus — Track Kebiasaan",
  description: "Pantau kebiasaan sehat harian mahasiswa.",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
