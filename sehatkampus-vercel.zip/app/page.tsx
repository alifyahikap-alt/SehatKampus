"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Activity, Droplets, Moon, Utensils, Brain, FileBarChart, Heart,
  Home, BookOpen, Phone, Plus, Minus, Check, ChevronRight, Menu,
  X, CalendarDays, Clock, Footprints, ShieldCheck, Sparkles, Coffee
} from "lucide-react";

type Entry = { water:number; meals:string[]; activity:number; sleep:number; mood:string; notes:string; done:string[] };
const todayKey = new Date().toISOString().slice(0,10);
const initial:Entry = {water:0, meals:[], activity:0, sleep:0, mood:"", notes:"", done:[]};
const nav = [
  ["Ringkasan","home"],["Aktivitas Fisik","activity"],["Pengingat Minum","water"],
  ["Pola Makan","food"],["Catatan Tidur","sleep"],["Kesehatan Mental","mental"],
  ["Informasi Kesehatan","learn"],["Laporan & Bantuan","report"]
] as const;
const tips = [
  "Sisihkan waktu untuk bergerak ringan setelah duduk cukup lama.",
  "Letakkan botol minum di tempat yang mudah terlihat agar tidak lupa minum.",
  "Usahakan punya waktu istirahat yang cukup di tengah jadwal kuliah.",
  "Makan secara teratur dapat membantu menjaga energi selama beraktivitas."
];

export default function Page() {
  const [entry,setEntry] = useState<Entry>(initial);
  const [section,setSection] = useState("home");
  const [mobileOpen,setMobileOpen] = useState(false);
  const [target,setTarget] = useState(8);
  const [wake,setWake] = useState("05:30");
  const [bed,setBed] = useState("22:30");
  const [toast,setToast] = useState("");
  useEffect(()=>{
    try {
      const saved = localStorage.getItem("sehatkampus-"+todayKey);
      if(saved) setEntry({...initial,...JSON.parse(saved)});
      const t = localStorage.getItem("sehatkampus-target");
      if(t) setTarget(Number(t));
    } catch {}
  },[]);
  useEffect(()=>{ try { localStorage.setItem("sehatkampus-"+todayKey,JSON.stringify(entry)); } catch {} },[entry]);
  useEffect(()=>{ try { localStorage.setItem("sehatkampus-target",String(target)); } catch {} },[target]);
  const doneCount = [entry.water>=target,entry.meals.length>0,entry.sleep>0,entry.activity>0,!!entry.mood].filter(Boolean).length;
  const percent = Math.round(doneCount/5*100);
  const duration = useMemo(()=>{
    const [bh,bm]=bed.split(":").map(Number), [wh,wm]=wake.split(":").map(Number);
    let mins=(wh*60+wm)-(bh*60+bm); if(mins<0) mins+=1440;
    return `${Math.floor(mins/60)} jam ${mins%60} menit`;
  },[bed,wake]);
  function update(p:Partial<Entry>){setEntry(v=>({...v,...p}));}
  function notify(s:string){setToast(s); setTimeout(()=>setToast(""),2200);}
  function addMeal(meal:string){update({meals:entry.meals.includes(meal)?entry.meals.filter(x=>x!==meal):[...entry.meals,meal]});}
  const activeLabel = nav.find(n=>n[1]===section)?.[0] || "Ringkasan";
  return <main className="app-shell">
    <aside className={`sidebar ${mobileOpen?"open":""}`}>
      <div className="brand"><div className="brand-mark"><Heart size={21} fill="currentColor"/></div><div><b>SehatKampus</b><small>TRACK KEBIASAAN</small></div><button className="close-nav" onClick={()=>setMobileOpen(false)}><X/></button></div>
      <div className="side-label">MENU UTAMA</div>
      <nav>{nav.map(([label,id])=><button key={id} className={`nav-item ${section===id?"selected":""}`} onClick={()=>{setSection(id);setMobileOpen(false)}}>{id==="home"?<Home/>:id==="activity"?<Activity/>:id==="water"?<Droplets/>:id==="food"?<Utensils/>:id==="sleep"?<Moon/>:id==="mental"?<Brain/>:id==="learn"?<BookOpen/>:<FileBarChart/>}<span>{label}</span>{section===id&&<ChevronRight className="nav-arrow"/>}</button>)}</nav>
      <div className="side-bottom"><div className="side-tip"><Sparkles size={18}/><b>Mulai dari hal kecil</b><p>Kebiasaan sehat dibangun sedikit demi sedikit. Tidak harus sempurna setiap hari.</p></div><div className="privacy"><ShieldCheck size={15}/> Data tersimpan di perangkat ini</div></div>
    </aside>
    {mobileOpen&&<div className="scrim" onClick={()=>setMobileOpen(false)}/>}
    <section className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobileOpen(true)}><Menu/></button><div><span className="eyebrow">RUANG KESEHATAN DIGITAL</span><h1>{activeLabel}</h1></div><div className="date-chip"><CalendarDays size={16}/>{new Date().toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long"})}</div></header>
      {section==="home"&&<div className="content">
        <section className="welcome"><div><span className="eyebrow light">HALO, MAHASISWA!</span><h2>Sehat dimulai dari<br/>kebiasaan hari ini.</h2><p>Pantau rutinitas sederhana dan kenali progres kesehatanmu setiap hari.</p><button className="white-btn" onClick={()=>setSection("report")}>Lihat laporan <ChevronRight size={16}/></button></div><div className="welcome-art"><div className="sun"></div><div className="plant">✳</div><div className="art-card"><Heart size={25} fill="currentColor"/><b>Take care<br/>of yourself</b><small>One day at a time</small></div></div></section>
        <div className="section-heading"><div><span className="eyebrow">PROGRES HARIAN</span><h3>Kebiasaan sehat hari ini</h3></div><span className="muted">{doneCount} dari 5 tercatat</span></div>
        <div className="progress-card"><div className="progress-info"><div><b>{percent}%</b><span> progres hari ini</span></div><p>{percent===100?"Hebat! Semua kebiasaan sudah tercatat.":"Setiap langkah kecil tetap berarti. Yuk, lanjutkan!"}</p></div><div className="progress-track"><div style={{width:percent+"%"}}/></div><div className="progress-foot"><span>Mulai</span><span>Target harian</span></div></div>
        <div className="section-heading compact"><div><span className="eyebrow">PANTAU RUTINITAS</span><h3>Menu kebiasaan</h3></div></div>
        <div className="habit-grid">
          <Habit icon={<Droplets/>} color="blue" title="Pengingat Minum" value={`${entry.water} / ${target} gelas`} desc="Catat air putih yang diminum" onClick={()=>setSection("water")}/>
          <Habit icon={<Utensils/>} color="orange" title="Pola Makan" value={`${entry.meals.length} waktu makan`} desc="Catat waktu makan harian" onClick={()=>setSection("food")}/>
          <Habit icon={<Moon/>} color="purple" title="Catatan Tidur" value={entry.sleep?`${entry.sleep} jam`:"Belum dicatat"} desc="Pantau waktu istirahat" onClick={()=>setSection("sleep")}/>
          <Habit icon={<Footprints/>} color="green" title="Aktivitas Fisik" value={`${entry.activity} menit`} desc="Catat aktivitas bergerak" onClick={()=>setSection("activity")}/>
          <Habit icon={<Brain/>} color="pink" title="Kesehatan Mental" value={entry.mood||"Belum check-in"} desc="Kenali perasaan hari ini" onClick={()=>setSection("mental")}/>
          <Habit icon={<BookOpen/>} color="teal" title="Info Kesehatan" value="Baca tips singkat" desc="Edukasi kesehatan terpercaya" onClick={()=>setSection("learn")}/>
        </div>
        <div className="bottom-grid"><div className="quote-card"><Sparkles/><div><b>Pengingat hari ini</b><p>{tips[new Date().getDate()%tips.length]}</p></div></div><div className="mini-card"><div className="mini-icon"><FileBarChart/></div><div><b>Laporan mingguan</b><p>Lihat catatan kebiasaanmu.</p></div><button onClick={()=>setSection("report")}><ChevronRight/></button></div></div>
      </div>}
      {section==="water"&&<div className="content"><PageIntro eyebrow="HIDRASI HARIAN" title="Jangan lupa minum air" desc="Catat jumlah gelas air putih yang kamu minum hari ini."/><div className="feature-grid"><div className="feature-card water-feature"><Droplets size={34}/><span>JUMLAH AIR HARI INI</span><strong>{entry.water}<small> gelas</small></strong><div className="water-track"><div style={{width:Math.min(100,entry.water/target*100)+"%"}}/></div><p>Target harian: {target} gelas</p><div className="stepper"><button onClick={()=>update({water:Math.max(0,entry.water-1)})}><Minus/></button><button onClick={()=>update({water:entry.water+1})}><Plus/> Tambah 1 gelas</button></div></div><div className="panel"><h3>Atur target minum</h3><p className="muted">Sesuaikan target pengingat dengan kebutuhan dan aktivitasmu.</p><div className="target-row"><button onClick={()=>setTarget(Math.max(1,target-1))}><Minus/></button><b>{target} <small>gelas</small></b><button onClick={()=>setTarget(Math.min(20,target+1))}><Plus/></button></div><div className="divider"/><h3>Jadwal pengingat</h3>{["08:00","10:00","12:00","14:00","16:00","18:00","20:00"].map(t=><div className="time-row" key={t}><Clock size={16}/><span>{t}</span><span className="muted">Waktu minum</span></div>)}</div></div></div>}
      {section==="food"&&<div className="content"><PageIntro eyebrow="POLA MAKAN" title="Catat waktu makanmu" desc="Tandai waktu makan yang sudah kamu lakukan hari ini. Tidak perlu mencatat secara berlebihan."/><div className="panel wide"><h3>Waktu makan hari ini</h3><p className="muted">Pilih semua yang sesuai.</p><div className="meal-list">{["Sarapan","Makan siang","Makan malam","Camilan"].map((m,i)=><button className={`meal ${entry.meals.includes(m)?"meal-done":""}`} onClick={()=>addMeal(m)} key={m}><span className="meal-icon">{i===0?"☀️":i===1?"🍚":i===2?"🌙":"🍎"}</span><span><b>{m}</b><small>{["Awali hari dengan sarapan","Isi energi di tengah aktivitas","Makan malam secukupnya","Camilan sesuai kebutuhan"][i]}</small></span>{entry.meals.includes(m)?<Check className="check"/>:<Plus className="muted"/>}</button>)}</div></div></div>}
      {section==="activity"&&<div className="content"><PageIntro eyebrow="AKTIVITAS FISIK" title="Bergerak di sela kesibukan" desc="Catat durasi aktivitas fisik yang kamu lakukan hari ini."/><div className="panel wide activity-panel"><div className="activity-number"><Activity/><strong>{entry.activity}</strong><span>menit aktivitas</span></div><div><h3>Tambah durasi aktivitas</h3><p className="muted">Termasuk jalan kaki, peregangan, bersepeda, atau olahraga ringan.</p><div className="quick-add">{[5,10,15,30].map(n=><button key={n} onClick={()=>update({activity:entry.activity+n})}>+{n} menit</button>)}</div><button className="text-btn" onClick={()=>update({activity:0})}>Atur ulang catatan</button></div></div></div>}
      {section==="sleep"&&<div className="content"><PageIntro eyebrow="CATATAN TIDUR" title="Berikan waktu untuk istirahat" desc="Masukkan perkiraan waktu tidur dan bangun untuk mencatat durasi istirahat."/><div className="feature-grid"><div className="sleep-summary"><Moon size={34}/><span>DURASI TIDUR TERCATAT</span><strong>{entry.sleep?`${entry.sleep} jam`:"—"}</strong><p>{entry.sleep?"Catatan tidur berhasil disimpan.":"Isi waktu tidur untuk melihat durasi."}</p></div><div className="panel"><h3>Waktu istirahat</h3><label className="field-label">Mulai tidur</label><input type="time" value={bed} onChange={e=>setBed(e.target.value)}/><label className="field-label">Waktu bangun</label><input type="time" value={wake} onChange={e=>setWake(e.target.value)}/><div className="duration-box"><span>Perkiraan durasi</span><b>{duration}</b></div><button className="primary-btn full" onClick={()=>{const h=Number(duration.split(" ")[0])+Number(duration.split(" ")[2])/60;update({sleep:Math.round(h*10)/10});notify("Catatan tidur disimpan")}}>Simpan catatan tidur</button></div></div></div>}
      {section==="mental"&&<div className="content"><PageIntro eyebrow="KESEHATAN MENTAL" title="Bagaimana perasaanmu hari ini?" desc="Luangkan waktu sejenak untuk mengenali perasaanmu. Semua perasaan boleh hadir."/><div className="panel wide"><h3>Cek perasaan hari ini</h3><div className="mood-grid">{[{m:"Senang",e:"😊"},{m:"Tenang",e:"😌"},{m:"Lelah",e:"😴"},{m:"Cemas",e:"😟"},{m:"Sedih",e:"😔"},{m:"Stres",e:"😣"}].map(x=><button key={x.m} className={`mood ${entry.mood===x.m?"mood-selected":""}`} onClick={()=>update({mood:x.m})}><span>{x.e}</span>{x.m}</button>)}</div><label className="field-label">Catatan pribadi (opsional)</label><textarea value={entry.notes} onChange={e=>update({notes:e.target.value})} placeholder="Tuliskan hal yang ingin kamu ingat hari ini..." rows={4}/><div className="calm-box"><Sparkles/><div><b>Coba jeda sejenak</b><p>Tarik napas perlahan, rilekskan bahu, lalu beri dirimu waktu untuk beristirahat.</p></div></div><button className="primary-btn" onClick={()=>notify("Check-in perasaan tersimpan di perangkat ini")}>Simpan check-in</button></div><p className="disclaimer">Fitur ini untuk refleksi diri dan edukasi, bukan alat diagnosis atau pengganti bantuan tenaga profesional.</p></div>}
      {section==="learn"&&<div className="content"><PageIntro eyebrow="LITERASI KESEHATAN" title="Informasi kesehatan" desc="Pengingat sederhana untuk mendukung kebiasaan hidup sehat di lingkungan kampus."/><div className="article-grid">{[{icon:"💧",t:"Penuhi kebutuhan cairan",p:"Biasakan minum air secara berkala, terutama saat kuliah atau beraktivitas. Sesuaikan dengan kebutuhan tubuh dan kondisi aktivitas."},{icon:"🥗",t:"Pola makan seimbang",p:"Usahakan makan teratur dan variasikan pilihan makanan agar kebutuhan gizi lebih beragam."},{icon:"🌙",t:"Jaga waktu istirahat",p:"Buat rutinitas tidur yang konsisten dan berikan waktu istirahat setelah kegiatan akademik."},{icon:"🚶",t:"Aktif bergerak",p:"Selingi waktu duduk dengan berdiri, peregangan, atau berjalan ringan."},{icon:"🧠",t:"Kelola tekanan akademik",p:"Bagi tugas menjadi langkah kecil, atur prioritas, dan bicarakan kesulitan dengan orang tepercaya."},{icon:"🛡️",t:"Cegah penyakit",p:"Jaga kebersihan tangan, terapkan etika batuk, dan cari informasi dari sumber kesehatan tepercaya."}].map(a=><div className="article" key={a.t}><span>{a.icon}</span><h3>{a.t}</h3><p>{a.p}</p><small>EDUKASI SEHATKAMPUS</small></div>)}</div></div>}
      {section==="report"&&<div className="content"><PageIntro eyebrow="EVALUASI KEBIASAAN" title="Ringkasan catatanmu" desc="Lihat kebiasaan yang sudah kamu catat hari ini dan gunakan sebagai bahan evaluasi."/><div className="report-summary"><div><span>PROGRES HARI INI</span><b>{percent}%</b><p>{doneCount} dari 5 kebiasaan terisi</p></div><div className="report-ring" style={{background:`conic-gradient(#269b83 ${percent*3.6}deg,#e8efed 0deg)`}}><div>{percent}%</div></div></div><div className="panel wide"><h3>Catatan hari ini</h3>{[{n:"Minum air putih",v:`${entry.water} dari ${target} gelas`,ok:entry.water>=target},{n:"Pola makan",v:`${entry.meals.length} waktu makan dicatat`,ok:entry.meals.length>0},{n:"Durasi tidur",v:entry.sleep?`${entry.sleep} jam`:"Belum dicatat",ok:entry.sleep>0},{n:"Aktivitas fisik",v:`${entry.activity} menit`,ok:entry.activity>0},{n:"Perasaan",v:entry.mood||"Belum check-in",ok:!!entry.mood}].map(r=><div className="report-row" key={r.n}><div className={`status-dot ${r.ok?"is-done":""}`}>{r.ok?<Check size={13}/>:null}</div><b>{r.n}</b><span>{r.v}</span></div>)}</div><div className="panel wide"><h3>Kontak bantuan</h3><p className="muted">Hubungi layanan kesehatan di lingkunganmu jika membutuhkan bantuan. Lengkapi nomor berikut sesuai fasilitas kampus setempat.</p><div className="contact-row"><Phone/><div><b>Klinik kampus</b><small>Tambahkan nomor resmi klinik kampus</small></div></div><div className="contact-row"><Brain/><div><b>Layanan konseling</b><small>Hubungi unit konseling resmi kampus</small></div></div><div className="contact-row"><Heart/><div><b>IGD rumah sakit terdekat</b><small>Gunakan nomor darurat resmi di wilayahmu</small></div></div></div><p className="disclaimer">Data pada versi demo ini tersimpan secara lokal di browser perangkatmu. Aplikasi bukan pengganti tenaga kesehatan profesional.</p></div>}
      <footer>© 2026 SehatKampus <span>Sehat di Kampus, Siap untuk Masa Depan.</span></footer>
    </section>
    {toast&&<div className="toast"><Check size={17}/>{toast}</div>}
  </main>;
}

function Habit({icon,color,title,value,desc,onClick}:{icon:React.ReactNode;color:string;title:string;value:string;desc:string;onClick:()=>void}){
 return <button className="habit-card" onClick={onClick}><div className={`habit-icon ${color}`}>{icon}</div><div className="habit-copy"><b>{title}</b><strong>{value}</strong><small>{desc}</small></div><ChevronRight className="habit-chevron"/></button>;
}
function PageIntro({eyebrow,title,desc}:{eyebrow:string;title:string;desc:string}){
 return <div className="page-intro"><span className="eyebrow">{eyebrow}</span><h2>{title}</h2><p>{desc}</p></div>;
}
