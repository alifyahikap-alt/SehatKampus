# SehatKampus — aplikasi web

Aplikasi demo SehatKampus berdasarkan materi presentasi Kelompok 2.

## Menjalankan di komputer
1. Install Node.js versi LTS.
2. Buka folder proyek di terminal.
3. Jalankan `npm install`.
4. Jalankan `npm run dev`, lalu buka alamat yang ditampilkan (biasanya http://localhost:3000).

## Deploy ke Vercel
1. Upload folder proyek ini ke repository GitHub.
2. Masuk ke https://vercel.com/new dan import repository tersebut.
3. Framework akan terdeteksi sebagai Next.js. Klik Deploy.

## Fitur
- Ringkasan progres kebiasaan harian
- Pencatatan air minum, pola makan, aktivitas fisik, tidur, dan check-in perasaan
- Edukasi kesehatan dan ringkasan catatan
- Data demo disimpan di localStorage browser, bukan server
- Kontak bantuan berupa placeholder yang perlu diisi dengan nomor resmi kampus

## Catatan
Versi ini merupakan prototipe frontend. Belum memiliki akun/login, database cloud, notifikasi terjadwal, sinkronisasi antarperangkat, atau kontak darurat terverifikasi. Jangan masukkan data pribadi/sensitif. Aplikasi bukan alat diagnosis dan bukan pengganti tenaga kesehatan profesional.
